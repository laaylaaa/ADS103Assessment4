// Alicia & Layla's Cool Code
// ADS103
// Assessment 4 
// T2 - 2021
// http://www.cppforschool.com/project/tic-tac-toe-project.html
// Logic for checking wins, to use char to mark the 'x's and 'o's,
// Helped give the basis on an idea on how to map out the grid!

#include <iostream>
#include <cstdlib>
#include <Windows.h>
#include <conio.h>
#include <stdlib.h>
#include <string>
#include "termcolor.h"

using namespace std;
using namespace termcolor;

// ---- LAYLA AND ALI'S COOL TIC TAC TOE GAME ----

// strings to hold what each square of grid say
string squareOne = "1"; 
string squareTwo = "2";
string squareThree = "3";
string squareFour = "4";
string squareFive = "5";
string squareSix = "6";
string squareSeven = "7";
string squareEight = "8";
string squareNine = "9";

// VARIABLES NEEDED THROUGHOUT VARIOUS FUNCTIONS
int winFound = 1;
int gameContinue = -1;
int gameTie = 0;

// Enum to hold what menu the player is currently on 
enum MenuChoice {
	PLAY_TTT = 1,
	QUIT = 2,
	CREDITS = 3,
	NO_CHOICE = -1
};

int displayMenu(){

	// Displays available screen to choose from (or quit)
	int choice = CREDITS;
	string error = "";

	do
	{
		// Beginning menu format, with colours. 
		cout << "-=-=-=-=-= " << green << "Welcome to TIC TAC TOE!" << reset << " =-=-=-=-=-\n\n";
		cout << yellow << "[  1. Play  ]" << "\n";
		cout << red << "[  2. Quit  ]" << "\n";
		cout << cyan << "[  3. Credits  ]" << "\n\n" << reset;
		// if there is an error, show it. 
		if (error != "")
		{
			cout << red << error;
			error = "";
		}

		cout << "[ Enter your choice ] > ";
		cin >> choice;
		cout << "\n\n\n";
		// ensure choice is valid
		// if they entered anything outside of 1,2 or 3
		// if the user choice is above 3 or below 1, it's an error

		if (choice < 1 || choice > 3)
		{
			error = "[ ERROR! Only 1, 2 or 3 accepted. Don't kill the beep boop bot! ]\n\n";
			system("cls");
		}

		// otherwise, return choice.

	} while (error != ""); // While there is an error / error isn't empty
	return choice;
}

void drawTTT() {

	system("cls"); // clear the scren before drawing the grid
	cout << green << "\n\n             = TIC TAC TOE =      \n\n" << reset;

	cout << magenta << "      Player 1 (X) " << green << " -  " << blue << "Player 2 (O)" << endl << endl << reset;
	cout << endl;

	cout << yellow << "\t        ||     ||     " << endl << reset;
	cout << "\t     " << reset << squareOne << yellow << "  ||  " << reset << squareTwo << yellow << "  ||  " << reset << squareThree << endl;

	cout << yellow << "\t   _____||_____||_____" << endl;
	cout << yellow << "\t        ||     ||     " << endl;

	cout << "\t     " << reset << squareFour << yellow << "  ||  " << reset << squareFive << yellow << "  ||  " << reset << squareSix << endl;

	cout << yellow << "\t   _____||_____||_____" << reset << endl;
	cout << yellow << "\t        ||     ||     " << reset << endl;

	cout << "\t     " << squareSeven << yellow << "  ||  " << reset << squareEight << yellow << "  ||  " << reset << squareNine << reset << endl;

	cout << yellow << "\t        ||     ||     \n\n" << reset << endl << endl;
}

int checkForWins() {
	
	// IF square one is equal to two AND square two equal to three
	// Top row win
	if (squareOne == squareTwo && squareTwo == squareThree)

		return winFound;
	// IF square four is equal to five AND square five is equal to six
	// Middle row win
	else if (squareFour == squareFive && squareFive == squareSix)

		return winFound;
	// IF square seven is equal to eight AND sqaure eight is equal to nine
	// Bottom row win
	else if (squareSeven == squareEight && squareEight == squareNine)

		return winFound;
	// IF square one is equal to four AND square four is equal to seven
	// Left column win
	else if (squareOne == squareFour && squareFour == squareSeven)

		return winFound;
	// IF square two is equal to sqaure five AND sqaure five is equal to eight 
	// Middle column win
	else if (squareTwo == squareFive && squareFive == squareEight)

		return winFound;
	// IF sqaure three is equal to square six && square six is equal to nine
	// Right column win 
	else if (squareThree == squareSix && squareSix == squareNine)

		return winFound;
	// IF square one is euqual to square five && square five is equal to sqaure nine
	// Left corner diagonal win
	else if (squareOne == squareFive && squareFive == squareNine)

		return winFound;
	// IF square three is eual to square five AND square five is equal to seven 
	// Right corner diagonal win
	else if (squareThree == squareFive && squareFive == squareSeven)

		return winFound;
	// IF all the spaces are taken then it is a TIE!
	else if (squareOne != "1" && squareTwo != "2" && squareThree != "3"
		&& squareFour != "4" && squareFive != "5" && squareSix != "6"
		&& squareSeven != "7" && squareEight != "8" && squareNine != "9")

		return gameTie;
	// IF no wins, the game continues 
	else 
		return gameContinue;
}

void boardReset() {
	
	// after a game has been played, we call this function to restart the board
	// to the original numbers
	squareOne = "1";
	squareTwo = "2";
	squareThree = "3";
	squareFour = "4";
	squareFive = "5";
	squareSix = "6";
	squareSeven = "7";
	squareEight = "8";
	squareNine = "9";
}

int playTicTacToe(){
	// Varaibles to hold Player, the mark, computer choices and player choices
	int player = 1, i, choice;
	char mark;
	int compChoice = 0;
	int compChoice2 = 0;
	int playerChoice = 0;

	//seed random number generator --> ensures numbers are always random
	srand(static_cast<unsigned int>(time(0))); 

	// booleans to check which spots have been taken 
	bool spotOneTaken = false, spotTwoTaken = false, spotThreeTaken = false, spotFourTaken = false;
	bool spotFiveTaken = false, spotSixTaken = false, spotSevenTaken = false, spotEightTaken = false;
	bool spotNineTaken = false;


	// Initialising the Tic Tac Toe function.
	// First, asking which game the player wants.

	cout << green << "\n[ What game mode?]";
	cout << "\n";
	cout << magenta << "\n[ 1. Player verses Player ]";
	cout << cyan << "\n[ 2. Player verses Computer ]" << reset;
	cout << yellow << "\n[ 3. Computer verses Computer ]" << reset;
	cout << "\n\n>> ";
	cin >> playerChoice;
	cout << "\n[ Loading... ]";
	Sleep(2000);

	// WHILE the player choice ISNT and option given to them, display an error!
	while (playerChoice < 1 || playerChoice > 3) {
		
		// yell at them
		cout << endl << red << "[ Hey! That isnt an option dummy! Pick 1, 2 or 3! ]" << endl << reset;
		cout << "\n\n>> ";
		cin >> playerChoice; // we give second chances
	}

	// If the player choice is player verses player and the game is still continuing
	if (playerChoice == 1 && gameContinue == -1)
	{
		do
		{
			system("cls"); // clear the screen 

			// title output
			cout << magenta << "\n[ Player verses Player. ]" << reset;

			drawTTT();

			// player is divided by two, therefore player can only be one or two. 
			player = (player % 2) ? 1 : 2;
			cout << magenta << "Player " << player << ", enter a number:  " << endl;
			cin >> choice;
			cout << reset;

			// sets the X and the O for players 1 and 2 
			mark = (player == 1) ? 'X' : 'O';

			// checks the spot chosen by the player, and if the spot is available 
			if (choice == 1 && squareOne == "1")

				squareOne = mark; // sets the spot to the players option

			else if (choice == 2 && squareTwo == "2")
				squareTwo = mark;

			else if (choice == 3 && squareThree == "3")
				squareThree = mark;

			else if (choice == 4 && squareFour == "4")
				squareFour = mark;

			else if (choice == 5 && squareFive == "5")
				squareFive = mark;

			else if (choice == 6 && squareSix == "6")
				squareSix = mark;

			else if (choice == 7 && squareSeven == "7")
				squareSeven = mark;

			else if (choice == 8 && squareEight == "8")
				squareEight = mark;

			else if (choice == 9 && squareNine == "9")
				squareNine = mark;

			else
			{
				// if the player picks a spot that is already taken, display an error!
				cout << "Invalid move ";

				// let them pick a new number 
				player--;
				cin.ignore();
				cin.get();
			}
			
			// calls the function to check if any of the players have won, if they have it changes
			// i to be -1
			i = checkForWins();

			// add one to player, to go to the next player
			player++;

		} while (i == -1); // if the number is -1 (there has been a winner) then exit the do while loop and declare the winner 

		drawTTT();
		// Display a win message if there is a win found
		if (i == 1)
			cout << green << "\n[ You've got some skill, Player " << --player << "! ]\n\n";
		// If not, the only option is a tie.
		else
			cout << red << "\n[ Tie! Better luck next time! ]";
		// Reset the board for next time. 
		boardReset();
	}
	// If the player choice is player verses computer and the game is still continuing:
	if (playerChoice == 2 && gameContinue == -1)
	{
		do
		{
			system("cls");
			// Reminds you, 'hey, you chose this mode.'
			cout << cyan << "\n[ Player verses Computer. ]" << reset;
			// Draw TTT, and choose player 1 out of 1 or 2.
			drawTTT();
			player = (player % 2) ? 1 : 2;
			// Let the mark char be 'X' for player 1, and 'O' for player 2.
			mark = (player == 1) ? 'X' : 'O';

			// if it is the human player - use this section.
			if (player == 1)
			{
				cout << cyan << "Player " << player << ", enter a number:  " << reset;
				cin >> choice;

			// See if the space is still available, mark the spot with the applicable symbol (x / o)
				if (choice == 1 && squareOne == "1") {
					squareOne = mark;
					spotOneTaken = true;
				}
				else if (choice == 2 && squareTwo == "2") {

					squareTwo = mark;
					spotTwoTaken = true;
				}
				else if (choice == 3 && squareThree == "3") {

					squareThree = mark;
					spotThreeTaken = true;
				}
				else if (choice == 4 && squareFour == "4") {

					squareFour = mark;
					spotFourTaken = true;
				}
				else if (choice == 5 && squareFive == "5") {

					squareFive = mark;
					spotFiveTaken = true;
				}
				else if (choice == 6 && squareSix == "6") {

					squareSix = mark;
					spotSixTaken = true;
				}
				else if (choice == 7 && squareSeven == "7") {

					squareSeven = mark;
					spotSevenTaken = true;
				}
				else if (choice == 8 && squareEight == "8") {

					squareEight = mark;
					spotEightTaken = true;
				}
				else if (choice == 9 && squareNine == "9") {

					squareNine = mark;
					spotNineTaken = true;
				}
				else
				{
					// Tell the player they messed up, and to do it AGAIN.
					cout << "Invalid move ";

					player--;
					cin.ignore();
					cin.get();
				}
			}

			if (player == 2) {
				// Choose a spot by the random generator, between 1-9!
				compChoice = rand() % 9 + 1;

				if (spotOneTaken == true || spotTwoTaken == true || spotThreeTaken == true || spotFourTaken == true || spotFiveTaken == true
					|| spotSixTaken == true || spotSevenTaken == true || spotEightTaken == true || spotNineTaken == true) {
					// While the choice made by the random generator is a space that has been taken, choose another.
					while (compChoice == 1 && spotOneTaken == true || compChoice == 2 && spotTwoTaken == true || compChoice == 3 && spotThreeTaken == true || compChoice == 4 && spotFourTaken == true
						|| compChoice == 5 && spotFiveTaken == true || compChoice == 6 && spotSixTaken == true || compChoice == 7 && spotSevenTaken || compChoice == 8 && spotEightTaken == true) {
						// chose another rand number
						compChoice = rand() % 9 + 1;
					}
				}
				// If the choice made by the random generator has been made, and the space is still available, mark the spot with the applicable symbol (x / o)
				if (compChoice == 1 && squareOne == "1") {
					squareOne = mark;
					spotOneTaken = true;
				}
				else if (compChoice == 2 && squareTwo == "2") {
					squareTwo = mark;
					spotTwoTaken = true;
				}
				else if (compChoice == 3 && squareThree == "3") {
					squareThree = mark;
					spotThreeTaken = true;
				}
				else if (compChoice == 4 && squareFour == "4") {
					squareFour = mark;
					spotFourTaken = true;
				}
				else if (compChoice == 5 && squareFive == "5") {

					squareFive = mark;
					spotFiveTaken = true;
				}
				else if (compChoice == 6 && squareSix == "6") {
					squareSix = mark;
					spotSixTaken = true;
				}
				else if (compChoice == 7 && squareSeven == "7") {
					squareSeven = mark;
					spotSevenTaken = true;
				}
				else if (compChoice == 8 && squareEight == "8") {
					squareEight = mark;
					spotEightTaken = true;
				}
				else if (compChoice == 9 && squareNine == "9") {
					squareNine = mark;
					spotNineTaken = true;
				}
			}

			// See if there are any wins!
			i = checkForWins();
			// If not, move to the next player from the last one
			player++;

		} 
		// While the game is still in progress - Draw the board each time.
		while (i == -1);
		drawTTT();
		// If there is a win, call it. Congratulate the player.
		if (i == 1)
			cout << green << "\n[ You've got some skill, Player " << --player << "! ]\n\n";
		// If there is no win, then it must be a tie. 
		else
			cout << red << "\n[ Tie! Better luck next time! ]";
		// Reset the board for the next game.
		boardReset();
	}
	// If the player choice is Computer verses computer and the game is still continuing:
	if (playerChoice == 3 && gameContinue == -1)
	{
		do
		{
			// Clear the screen and begin the Computer Verses!
			system("cls");

			cout << yellow << "\n[ Computer verses Computer. ]" << reset;

			drawTTT();
			player = (player % 2) ? 1 : 2;
			mark = (player == 1) ? 'X' : 'O';

			if (player == 1)
			{
				// Choose a spot by the random generator, between 1-9!
				if (spotOneTaken == false || spotTwoTaken == false || spotThreeTaken == false || spotFourTaken == false || spotFiveTaken == false
					|| spotSixTaken == false || spotSevenTaken == false || spotEightTaken == false || spotNineTaken == false) {

					compChoice = rand() % 9 + 1;
					// While the choice made by the random generator is a space that has been taken, choose another.
					while (compChoice == 1 && spotOneTaken == true || compChoice == 2 && spotTwoTaken == true || compChoice == 3 && spotThreeTaken == true || compChoice == 4 && spotFourTaken == true
						|| compChoice == 5 && spotFiveTaken == true || compChoice == 6 && spotSixTaken == true || compChoice == 7 && spotSevenTaken || compChoice == 8 && spotEightTaken == true || 
						compChoice == 9 && spotNineTaken == true) {
						// choose another rand number
						compChoice = rand() % 9 + 1;
					}
				}
				// If the choice made by the random generator has been made, and the space is still available, mark the spot with the applicable symbol (x / o)
				if (compChoice == 1 && squareOne == "1") {
					squareOne = mark;
					spotOneTaken = true;
				}
				else if (compChoice == 2 && squareTwo == "2") {
					squareTwo = mark;
					spotTwoTaken = true;
				}
				else if (compChoice == 3 && squareThree == "3") {
					squareThree = mark;
					spotThreeTaken = true;
				}
				else if (compChoice == 4 && squareFour == "4") {
					squareFour = mark;
					spotFourTaken = true;
				}
				else if (compChoice == 5 && squareFive == "5") {
					squareFive = mark;
					spotFiveTaken = true;
				}
				else if (compChoice == 6 && squareSix == "6") {
					squareSix = mark;
					spotSixTaken = true;
				}
				else if (compChoice == 7 && squareSeven == "7") {
					squareSeven = mark;
					spotSevenTaken = true;
				}
				else if (compChoice == 8 && squareEight == "8") {
					squareEight = mark;
					spotEightTaken = true;
				}
				else if (compChoice == 9 && squareNine == "9") {
					squareNine = mark;
					spotNineTaken = true;
				}
			}

			Sleep(700);

			if (player == 2) {

				// Choose a spot by the random generator, between 1-9!
				if (spotOneTaken == false || spotTwoTaken == false || spotThreeTaken == false || spotFourTaken == false || spotFiveTaken == false
					|| spotSixTaken == false || spotSevenTaken == false || spotEightTaken == false || spotNineTaken == false) {

					compChoice2 = rand() % 9 + 1;
					// While the choice made by the random generator is a space that has been taken, choose another.
					while (compChoice2 == 1 && spotOneTaken == true || compChoice2 == 2 && spotTwoTaken == true || compChoice2 == 3 && spotThreeTaken == true || compChoice2 == 4 && spotFourTaken == true
						|| compChoice2 == 5 && spotFiveTaken == true || compChoice2 == 6 && spotSixTaken == true || compChoice2 == 7 && spotSevenTaken || compChoice2 == 8 && spotEightTaken == true ||
							compChoice2 == 9 && spotNineTaken == true) {
						// chose another rand number
						compChoice2 = rand() % 9 + 1;
					}
				}
			// If the choice made by the random generator has been made, and the space is still available, mark the spot with the applicable symbol (x / o)
				if (compChoice2 == 1 && squareOne == "1") {
					squareOne = mark;
					spotOneTaken = true;
				}
				else if (compChoice2 == 2 && squareTwo == "2") {
					squareTwo = mark;
					spotTwoTaken = true;
				}
				else if (compChoice2 == 3 && squareThree == "3") {
					squareThree = mark;
					spotThreeTaken = true;
				}
				else if (compChoice2 == 4 && squareFour == "4") {
					squareFour = mark;
					spotFourTaken = true;
				}
				else if (compChoice2 == 5 && squareFive == "5") {
					squareFive = mark;
					spotFiveTaken = true;
				}
				else if (compChoice2 == 6 && squareSix == "6") {
					squareSix = mark;
					spotSixTaken = true;
				}
				else if (compChoice2 == 7 && squareSeven == "7") {
					squareSeven = mark;
					spotSevenTaken = true;
				}
				else if (compChoice2 == 8 && squareEight == "8") {
					squareEight = mark;
					spotEightTaken = true;
				}
				else if (compChoice2 == 9 && squareNine == "9") {
					squareNine = mark;
					spotNineTaken = true;
				}
			}
			Sleep(700);

			// See if there are any wins!
			i = checkForWins();
			// If not, move to the next player from the last one
			player++;

		} 
		// While the game is still in progress - Draw the board each time.
		while (i == -1);
		drawTTT();
		// If there is a win, call it. Congratulate the player.
		if (i == 1)
			cout << green << "\n[ You've got some skill, Player " << --player << "! ]\n\n";
		// If there is no win, then it must be a tie. 
		else
			cout << red << "\n[ Tie! Better luck next time! ]";
		// Reset the board for the next game.
		boardReset();
	}

	// Waiting for the input from the player to return to the menu
	cout << white << on_blue << "\n[ -= Press any key to return to the menu... =-]\n" << reset;
	_getch();
	return winFound;
}

// Display info about the makers!

void displayCredits(){
	// A new screen that shows a few lines containing people who made the game!
	cout << "\n\n";
	cout << cyan << " [ -=-=-=-=-=-=-=-=-=-=-=-=-=- ] \n";
	cout << " [ " << white << "Developed by ...            " << cyan << "] \n";
	Sleep(300);
	cout << " [                             ] \n";
	Sleep(300);
	cout << " [ \t" << white << " *Drum roll...*        " << cyan << "] \n";
	cout << " [                             ] \n";
	cout << " [       " << yellow << "     Alicia McEwen    " << cyan << "] \n";
	cout << " [                     &       ] \n";
	cout << " [       " << yellow << "     Layla Darwiche   " << cyan << "] \n";
	cout << cyan << " [ -=-=-=-=-=-=-=-=-=-=-=-=-=- ] \n";
	Sleep(2000);
	// Sleep functions are to hold the player's attention, make it seem more like credits each time. 


	// Once done, display a message "Hit any key to return to menu."
	// Wait for that keypress before ending function.

	cout << blue << "\n[ Press any key to return to the menu ... ]\n" << reset;
	_getch();
}


void displayQuit(){
	// Exit screen! Hit a key to close the Tictactoe game.
	cout << cyan << "\n[ See you next time ... ]\n";
	cout << cyan << "\n[ Press any key to quit ]" << reset << "\n";
	_getch();

	return;
}

int main(){
	// this is our function calls and processes the whole game.
	int choice = NO_CHOICE;

	do
	{
		system("cls");
		choice = displayMenu();

		if (choice == PLAY_TTT)
		{
			system("cls");
			playTicTacToe();
		}
		else if (choice == CREDITS)
		{
			system("cls");
			displayCredits();
		}
	} while (choice != QUIT);
	//loop while the player choice isn't quit

	system("cls");
	displayQuit();
}