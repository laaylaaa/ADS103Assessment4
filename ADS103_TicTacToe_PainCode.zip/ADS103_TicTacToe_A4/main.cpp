#include <iostream>
#include <string>
#include <windows.h>  
#include <vector>
#include <chrono>
#include "termcolor.h"

using namespace std;
using namespace termcolor;

// -------- JUST PAIN CODE ------------
// --------- SIGNING OUT --------------

// For different screens of the game 
enum Screen {

	MENU,
	HUMvsHUM = 1,
	COMPvsHUM = 2,
	EXIT = 3,
	NONE
};

// DECLARATIONS OF FUNCTIONS 
int displayMenuScreen();
void displayGrid();
int playCompVSHum();
int player1HumVSHum(vector<int> playerTwoChoices, bool printed);
int player2HumVSHum(vector<int> playerOneChoices, int grid[], int gridSize);

int main() {

	int choice = NONE; // set to a value no one can pick
	vector<int> playerTwoChoices;
	bool printed = false; 

	do {
		system("cls");
		choice = displayMenuScreen();

		if (choice == HUMvsHUM) {
			system("cls");
			player1HumVSHum(playerTwoChoices, printed);
		}
		else if (choice == COMPvsHUM) {
			system("cls");
			playCompVSHum();
		}

	} while (choice != EXIT);

	// DO A QUIT SCENE
	cout << endl << "\tSee ya" << endl;
	system("pause");
	//quitScreen();
}

int displayMenuScreen() {

	int choice = Screen::NONE;
	string error = ""; // empty string

	do {

		cout << endl;
		cout << magenta << "\t\t--------- LETS PLAY " << yellow << "TIC TAC TOE" << magenta << " ---------\n\n " << termcolor::reset;
		cout << magenta << "\t\t\t--------- MENU ---------\n\n" << termcolor::reset;
		cout << yellow << "\t1." << white << "Play with a Friend!" << endl
			<< yellow << "\t2." << white << "Play with a Computer!" << endl
			<< yellow << "\t3." << white << "Quit Game" << endl;

		// if there is an error, show it 
		if (error != "") {
			cout << red << error << white;
			error = "";
		}
		cout << yellow << "\t>> ";

		cin >> choice;
		cout << endl;

		// if their choice isnt in the menu, then error 
		if (choice < 1 || choice > 3)
		{
			error = "\tHey! That isnt an option...try again\n";
			system("cls");
		}

	} while (error != "");

	return choice;
}

void displayGrid() {
	cout << white << "\t1" << yellow << " | " << white << "2" << yellow << " | " << white << "3" << endl << termcolor::reset;
	cout << yellow << "\t==" << " ==" << " ==" << endl << termcolor::reset;
	cout << white << "\t4" << yellow << " | " << white << "5" << yellow << " | " << white << "6" << endl << termcolor::reset;
	cout << yellow << "\t==" << " ==" << " ==" << endl << termcolor::reset;
	cout << white << "\t7" << yellow << " | " << white << "8" << yellow << " | " << white << "9" << endl << termcolor::reset;
	cout << yellow << "\t==" << " ==" << " ==" << endl << termcolor::reset;
}

int playCompVSHum()
{
	cout << magenta << "\t\t\t--------- COMPUTER VS PLAYER ---------\n\n" << termcolor::reset;
	cout << endl;
	cout << "\tYou are" << green << " GREEN!" << white << " Input a number from the grid to claim that spot!" << endl << endl;
	displayGrid();
	int yuh;
	cin >> yuh;
	return 0;
}

int player1HumVSHum(vector<int> playerTwoChoices, bool printed = true)
{

	int playerOne;
	vector<int> playerOneChoices;
	int grid[9] = { 1, 2, 3, 4, 5, 6, 7 ,8, 9 };
	int gridSize = sizeof(grid) / sizeof(grid[0]);
	string error = "";

	do {

		if (printed) {
			cout << white << "\tTry make three in a row!" << endl << termcolor::reset; 
		}
		else {
			cout << magenta << "\t\t\t--------- PLAYER VS PLAYER ---------\n\n" << termcolor::reset;
			cout << "\tPlayer 1 is" << green << " GREEN!" << white << " Player 2 is" << red << " RED!" << white << endl << endl;
			cout << " \tInput a number from the grid to claim that spot!" << endl << endl;
			displayGrid();
			cout << endl << endl;
			printed = true; 
		}
		if (error != "") {
			cout << red << error << endl;
			error = "";
		}

		std::chrono::steady_clock::time_point begin1 = std::chrono::steady_clock::now(); // start timer 
		cout << white << "\tPlayer " << green << "ONE!" << white << " Go!" << endl;
		cout << green << "\t> ";

		cin >> playerOne;
		std::chrono::steady_clock::time_point end1 = std::chrono::steady_clock::now(); // end timer


		auto timeTook1 = chrono::duration_cast<chrono::seconds>(end1 - begin1);
		if (playerOne >= 1 && playerOne <= 9) {
			// checks if the number has been picked before 
			if (count(playerOneChoices.begin(), playerOneChoices.end(), playerOne) || count(playerTwoChoices.begin(), playerTwoChoices.end(), playerOne)) {
				// if it has print out an error message and let them try again
				cout << "\t This spots taken! Pick another number!" << endl;
				cout << green << "\t> ";
				cin >> playerOne;
			}
			for (int i = 0; i < gridSize; i++) {

				if (playerOne == grid[i])
					playerOneChoices.push_back(playerOne);
			}
		}

		if (playerOne < 1 || playerOne > 9) {
			error = "\tYour number isnt in the grid!! Try Again";
		}


	} while (error != "" && playerOne != NULL);

	player2HumVSHum(playerOneChoices, grid, gridSize);

	return 0;
}

int player2HumVSHum(vector<int> playerOneChoices, int grid[], int gridSize) {

	int playerTwo;
	vector<int> playerTwoChoices;
	string error = "";
	bool printed = true; 

	do {

		//display error message
		if (error != "") {
			cout << red << error << white;
			error = "";
		}

		std::chrono::steady_clock::time_point begin2 = std::chrono::steady_clock::now(); // start timer 
		cout << white << "\tPlayer " << red << "TWO!" << white << " Go!" << endl;
		cout << red << "\t> ";
		cin >> playerTwo;
		std::chrono::steady_clock::time_point end2 = std::chrono::steady_clock::now(); // end timer

		if (playerTwo >= 1 && playerTwo <= 9) {
			if (count(playerTwoChoices.begin(), playerTwoChoices.end(), playerTwo) || count(playerOneChoices.begin(), playerOneChoices.end(), playerTwo)) {
				cout << "\t This spots taken! Pick another number!" << endl;
				cout << red << "\t> ";
				cin >> playerTwo;
			}

			for (int i = 0; i < gridSize; i++) {

				if (playerTwo == grid[i])
					playerTwoChoices.push_back(playerTwo);
			}
		}
		else {
			error = "Your number isnt in the grid!! Try Again";
		}

		if (playerTwo < 1 || playerTwo > 9) {
			error = "Your number isnt in the grid!! Try Again";
		}

		//for (int i = 0; i < playerOneChoices.size(); i++) 
		//	cout << endl << "Player one choices " << playerOneChoices[i] << " ";


		//for (int i = 0; i < playerTwoChoices.size(); i++) 
		//	cout << endl << "Player two choices " << playerTwoChoices[i] << " "; 

		cout << endl;

	} while (error != "" && playerTwo != NULL);

	player1HumVSHum(playerTwoChoices, printed);

	return 0;
}